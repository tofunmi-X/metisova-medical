METISOVA MEDICAL WEBSITE

GitHub Pages:
1. Create a repository and upload index.html.
2. Settings -> Pages -> Deploy from branch -> main -> root.
3. Add medical.metisova.com as the custom domain.

Hostinger DNS:
Create a CNAME record:
Name: medical
Target: YOUR-GITHUB-USERNAME.github.io
TTL: 14400 is fine.

Replace the example email addresses with your actual company addresses before launch.
The product descriptions are deliberately framed as prospective R&D concepts, not validated/commercial products.
